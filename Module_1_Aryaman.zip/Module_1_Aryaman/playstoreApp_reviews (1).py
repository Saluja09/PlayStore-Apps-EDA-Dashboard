#!/usr/bin/env python
# coding: utf-8

# # Import Libraries:

# In[1]:


import numpy as np
import pandas as pd


# # Loading the Dataset:

# In[2]:


data = pd.read_csv("playstore_reviews.csv",index_col = 'App')


# In[3]:


data


# In[4]:


data.shape


# In[5]:


data.isna().sum()


# In[6]:


data.dropna(subset = ['Translated_Review'], inplace = True)


# In[7]:


data.dropna(inplace = True)


# In[8]:


data.isna().sum()


# In[9]:


data


# In[10]:


data.to_csv("Playstoreapp_Reviews.csv")





